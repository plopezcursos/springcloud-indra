package curso.springcloud.cloud.saludo;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class CloudSaludoApplicationTests {

	@Test
	void contextLoads() {
	}

}
