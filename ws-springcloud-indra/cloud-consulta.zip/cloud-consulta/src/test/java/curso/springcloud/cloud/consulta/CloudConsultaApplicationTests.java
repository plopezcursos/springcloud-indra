package curso.springcloud.cloud.consulta;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class CloudConsultaApplicationTests {

	@Test
	void contextLoads() {
	}

}
