package es.formacion.cursoindra.cuenta.model;

import jakarta.persistence.Column;
import jakarta.persistence.Entity;
import jakarta.persistence.GeneratedValue;
import jakarta.persistence.GenerationType;
import jakarta.persistence.Id;
import jakarta.persistence.Table;

@Entity
@Table(name = "tarjetas")
public class Tarjeta {
	@Id
	@GeneratedValue(strategy = GenerationType.IDENTITY)
	@Column(name = "id_tarjeta")
	private Integer idTarjeta;

	@Column(name = "pan_ficticio", nullable = false)
	private String pan;

	@Column(nullable = false)
	private String marca;

	@Column(nullable = false)
	private String tipo;

	@Column(name = "fk_cuenta", nullable = false)
	private Integer idCuenta;

	protected Tarjeta() {
	}

	public Integer getIdTarjeta() {
		return idTarjeta;
	}

	public String getPan() {
		return pan;
	}

	public String getMarca() {
		return marca;
	}

	public String getTipo() {
		return tipo;
	}

	public Integer getIdCuenta() {
		return idCuenta;
	}
}
