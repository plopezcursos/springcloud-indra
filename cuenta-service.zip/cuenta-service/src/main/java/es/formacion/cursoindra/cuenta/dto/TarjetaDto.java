package es.formacion.cursoindra.cuenta.dto;

public record TarjetaDto(
	Integer idTarjeta,
	String pan,
	String marca,
	String tipo,
	Integer idCuenta
) {}
