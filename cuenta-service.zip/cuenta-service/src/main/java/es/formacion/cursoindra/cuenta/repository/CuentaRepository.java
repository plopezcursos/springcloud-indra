package es.formacion.cursoindra.cuenta.repository;

import java.util.List;

import org.springframework.data.jpa.repository.JpaRepository;

import es.formacion.cursoindra.cuenta.model.Cuenta;

public interface CuentaRepository extends JpaRepository<Cuenta, Integer> {

	List<Cuenta> findByIdCliente(Integer idCliente);
}
