package es.formacion.cursoindra.cuenta.repository;

import java.util.List;

import org.springframework.data.jpa.repository.JpaRepository;

import es.formacion.cursoindra.cuenta.model.Tarjeta;

public interface TarjetaRepository extends JpaRepository<Tarjeta, Integer> {
	List<Tarjeta> findByIdCuentaIn(List<Integer> idsCuenta);
}
