package es.formacion.cursoindra.cuenta.dto;

public record CuentaResp(
	Integer idCuenta, 
	String nroCuenta, 
	Integer idCliente
) {}
