package es.formacion.cursoindra.cuenta.service;

import java.util.List;

import org.springframework.stereotype.Service;

import es.formacion.cursoindra.cuenta.dto.CuentaResp;
import es.formacion.cursoindra.cuenta.dto.CuentaTarjetasResp;
import es.formacion.cursoindra.cuenta.dto.TarjetaDto;
import es.formacion.cursoindra.cuenta.model.Cuenta;
import es.formacion.cursoindra.cuenta.repository.CuentaRepository;
import es.formacion.cursoindra.cuenta.repository.TarjetaRepository;
import lombok.RequiredArgsConstructor;

@Service
@RequiredArgsConstructor
public class CuentaService {

	private final CuentaRepository cueRepo;
	private final TarjetaRepository tarjetaRepo;

	public List<CuentaResp> findAll() {
		return cueRepo.findAll().stream()
				.map(cue -> new CuentaResp(cue.getIdCuenta(), cue.getNroCuenta(), cue.getIdCliente())).toList();
	}

	public CuentaResp findById(Integer cuentaId) {
		return toResponse(cueRepo.findById(cuentaId).orElseThrow());
	}

	public List<CuentaResp> findByCliente(Integer clienteId) {
		return cueRepo.findByIdCliente(clienteId).stream()
				.map(cue -> new CuentaResp(cue.getIdCuenta(), cue.getNroCuenta(), cue.getIdCliente())).toList();
	}

	public List<CuentaTarjetasResp> findByClienteConTarjetas(Integer clienteId) {
		var cuentas = cueRepo.findByIdCliente(clienteId);
		var idsCuenta = cuentas.stream().map(Cuenta::getIdCuenta).toList();
		if (idsCuenta.isEmpty())
			return List.of();
		var tarjetasPorCuenta = tarjetaRepo.findByIdCuentaIn(idsCuenta).stream()
				.map(t -> new TarjetaDto(t.getIdTarjeta(), t.getPan(), t.getMarca(), t.getTipo(), t.getIdCuenta()))
				.collect(java.util.stream.Collectors.groupingBy(TarjetaDto::idCuenta));
		return cuentas.stream().map(c -> new CuentaTarjetasResp(c.getIdCuenta(), c.getNroCuenta(), c.getIdCliente(),
				tarjetasPorCuenta.getOrDefault(c.getIdCuenta(), List.of()))).toList();
	}

	private CuentaResp toResponse(Cuenta c) {
		return new CuentaResp(c.getIdCuenta(), c.getNroCuenta(), c.getIdCliente());
	}

}
