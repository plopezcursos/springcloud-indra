package es.formacion.cursoindra.cuenta.model;

import java.io.Serializable;
import java.util.Objects;

import jakarta.persistence.Column;
import jakarta.persistence.Entity;
import jakarta.persistence.GeneratedValue;
import jakarta.persistence.GenerationType;
import jakarta.persistence.Id;
import jakarta.persistence.Table;

@SuppressWarnings("serial")

@Entity
@Table(name = "cuentas")
public class Cuenta implements Comparable<Cuenta>, Serializable {

	@Id
	@GeneratedValue(strategy = GenerationType.IDENTITY)
	@Column(name = "id_cuenta")
	private Integer idCuenta;

	@Column(name = "numero")
	private String nroCuenta;

	@Column(name = "fk_cliente")
	private Integer idCliente;

	public Cuenta() {
	}

	public Cuenta(String nroCuenta) {
		this(null, nroCuenta);
	}

	public Cuenta(Integer idCuenta, String nroCuenta) {
		this.idCuenta = idCuenta;
		this.nroCuenta = nroCuenta;
	}

	public Integer getIdCuenta() {
		return idCuenta;
	}

	public void setIdCuenta(Integer idCuenta) {
		this.idCuenta = idCuenta;
	}

	public String getNroCuenta() {
		return nroCuenta;
	}

	public void setNroCuenta(String nroCuenta) {
		this.nroCuenta = nroCuenta;
	}

	public Integer getIdCliente() {
		return idCliente;
	}

	public void setIdCliente(Integer idCliente) {
		this.idCliente = idCliente;
	}

	@Override
	public int hashCode() {
		return Objects.hash(idCuenta);
	}

	@Override
	public boolean equals(Object obj) {
		if (this == obj)
			return true;
		if (obj == null)
			return false;
		if (getClass() != obj.getClass())
			return false;
		Cuenta other = (Cuenta) obj;
		return Objects.equals(idCuenta, other.idCuenta);
	}

	@Override
	public String toString() {
		StringBuilder cuenta = new StringBuilder();
		for (int i = 0; i < nroCuenta.length(); i++) {
			if (i % 4 == 0 && i != 0)
				cuenta.append(" ");
			cuenta.append(nroCuenta.charAt(i));
		}
		return cuenta.toString();
	}

	@Override
	public int compareTo(Cuenta o) {
		return Integer.compare(this.idCuenta, o.idCuenta);
	}
}
