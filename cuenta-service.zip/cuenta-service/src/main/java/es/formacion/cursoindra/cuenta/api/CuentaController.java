package es.formacion.cursoindra.cuenta.api;

import java.util.List;

import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RestController;

import es.formacion.cursoindra.cuenta.dto.CuentaResp;
import es.formacion.cursoindra.cuenta.dto.CuentaTarjetasResp;
import es.formacion.cursoindra.cuenta.service.CuentaService;
import lombok.RequiredArgsConstructor;

@RestController
@RequiredArgsConstructor
public class CuentaController {

	private final CuentaService cueService;

	@GetMapping("/api/cuentas")
	public List<CuentaResp> findAll() {
		return cueService.findAll();
	}

	@GetMapping("/api/cuentas/{id}")
	public CuentaResp findById(@PathVariable("id") Integer id) {
		return cueService.findById(id);
	}

	@GetMapping("/internal/cuentas/by-cliente/{id}")
	public List<CuentaResp> findByCliente(@PathVariable("id") Integer id) {
		return cueService.findByCliente(id);
	}

	@GetMapping("/internal/cuentas-tarjetas/by-cliente/{id}")
	public List<CuentaTarjetasResp> findByClienteConTarjetas(@PathVariable("id") Integer id) {
		return cueService.findByClienteConTarjetas(id);
	}
}
