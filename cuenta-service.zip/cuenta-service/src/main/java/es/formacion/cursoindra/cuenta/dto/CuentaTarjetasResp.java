package es.formacion.cursoindra.cuenta.dto;

import java.util.List;

public record CuentaTarjetasResp(
	Integer idCuenta, 
	String nroCuenta,
	Integer idCliente,
	List<TarjetaDto> tarjetas
) {}
